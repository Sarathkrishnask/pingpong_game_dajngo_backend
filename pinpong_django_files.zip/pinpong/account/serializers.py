from django.contrib.auth import get_user_model
from rest_framework import serializers

from account import models as account_model

User = get_user_model()


"""
The setpassword serializer class is used to update the password in database"""

class setPasswordSerializer(serializers.ModelSerializer):
    Dob = serializers.DateField(format='%Y-%m-%d', input_formats=['%Y-%m-%d', 'iso-8601'])
    class Meta:
        model = User
        fields = "__all__"

    def update(self, instance,data):
        """
        Update method to update the password of a user instance.
        """
        instance.set_password(data.get('password'))
        instance.save()
        instance.refresh_from_db()
        return instance


    
class UserSerializer(serializers.ModelSerializer):
    """
    Serializer for the User model.
    """

    class Meta:
         # Specifies the model to be serialized
        model = User
        
        # Specifies the fields from the model to be included in the serialization
        fields = ["firstname","lastname","phone_number","email"]
    
        
 
     
