

"""
import django functions
"""
from django.contrib.auth import get_user_model
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator
from django.contrib.auth.hashers import make_password,check_password


"""
import apps,account_model,serializers
"""
from account import models as account_model
# from account import serializers
# from pingpong import settings
# from apps.admin import account_model as admin_account_model


"""
import restframeworks functions
"""
from rest_framework.views import APIView
from rest_framework import permissions
# from rest_framework import status

"""
import utils functions
"""
from utils import json
from utils import functions



"""
other imports
"""
import json as j
import logging

from datetime import datetime,timezone
logger = logging.getLogger(__name__)
User = get_user_model()

# Create your views here.
now = datetime.now(timezone.utc)
current_date = now.date()
current_time = now.time()


class UserRegister(APIView):
    """
    Registeration of user
    
    """
    # Disables CSRF protection for this view
    @method_decorator(csrf_exempt)
    def dispatch(self, request, *args, **kwargs):
        return super(UserRegister, self).dispatch(request, *args, **kwargs)

    @csrf_exempt
    def post(self, request):
        
        try:
            # Extracting data from request body
            datas = j.loads(request.body)

            # Hashing the password before storing it
            datas["password"] = make_password(datas["password"])

            # Creating a new user object with provided data
            account_model.User.objects.create(**datas)

            # Fetching user data from the database
            user_datas = account_model.User.objects.get(email=datas['email'])
            user_Name_id = account_model.User.objects.filter(email=datas['email']).first()
            user_details = {}

            # Authenticating user and generating JWT tokens
            getjwt=functions.emailauth(user_datas,user_Name_id.id)
            user_details['access_token'] = getjwt['access_token']
            user_details['refresh_token'] = getjwt['refresh_token']

            # Constructing user info data
            user_details['user_info'] = {"id":user_Name_id.id,
                                        "name":str(user_Name_id.firstname) ,
                                        "email":user_Name_id.email,
                                        "phone_number":user_Name_id.phone_number}
            
            # Returning success response with user details
            logger.info(f"{current_date} {current_time} : {user_Name_id.id}: User created successfully")
            return json.Response({"data":user_details},"User created successfully",201,True)

        except Exception as e:
            logger.info(f"{current_date} {current_time} : {e}: While Creating event")
            # Handling exceptions and returning error response
            return json.Response({"data":[]},f"{e}Internal Server Error", 400,False)





class AdminLoginApi(APIView):
    """
    login using Email
    """
    # Allows any user (even unauthenticated) to access this endpoint
    permission_classes=[permissions.AllowAny]

    # Disables CSRF protection for this view
    @method_decorator(csrf_exempt)
    def dispatch(self, request, *args, **kwargs):
        return super(AdminLoginApi, self).dispatch(request, *args, **kwargs)

    @csrf_exempt
    def post(self,request):
        try:
            # Parsing JSON data from request body
            datas = j.loads(request.body.decode('utf-8'))

            # Checking if email exists in the database
            user_data = account_model.User.objects
            if not user_data.filter(email=datas['email']).exists():
                return json.Response({"data":[]},"Please enter registered email",400, False)

            # Checking if password is provided
            if len(datas['password']) == 0 or datas['password'] == '':
                return json.Response({"data":[]},"Please enter password",400, False)

            # Retrieving user object from database based on email
            user_datas = account_model.User.objects.get(email=datas['email'])
            user_Name_id = account_model.User.objects.filter(email=datas['email']).first()

            # Validating user and generating JWT tokens
            if user_Name_id:

                user_details = {}

                # Authenticating user and generating JWT tokens
                getjwt=functions.emailauth(user_datas,user_Name_id.id)
                user_details['access_token'] = getjwt['access_token']
                user_details['refresh_token'] = getjwt['refresh_token']
                user_details['user_info'] = {"id":user_Name_id.id,
                                                    "name":str(user_Name_id.firstname),
                                                    "email":user_Name_id.email,
                                                    "phone_number":user_Name_id.phone_number}
                
                logger.info(f"{current_date} {current_time} : {user_Name_id.id}: User Logged successfully")
                # Returning success response with user details
                return json.Response({"data":user_details},"Logged In Successfully",200,True)
            else:
                logger.info(f"{current_date} {current_time} : Give valid register id")
                return json.Response({"data":user_details},"Please provide your valid registered id",400,True)

        except Exception as e:
            logger.info(f"{current_date} {current_time} : {e}: error ")
            # Handling exceptions and returning error response
            return json.Response({"data":[]},f"{e}Internal Server Error", 400,False)



class playerData(APIView):
    """
    API for saving player data.
    """
    @method_decorator(csrf_exempt)
    def dispatch(self, request, *args, **kwargs):
        return super(playerData, self).dispatch(request, *args, **kwargs)

    @csrf_exempt
    def post(self, request):
        print("data_in")
        try:
            # Parsing JSON data from request body
            datas = j.loads(request.body)
            
            # Creating a new player history object with provided data
            player_details = account_model.PlayerHisory.objects.create(**datas)
            
            # Returning success response
            return json.Response({"data":player_details},"player data saved Successfully",200,True)

        except Exception as e:
            logger.info(f"{current_date} {current_time} : {e}: error ")
            # Handling exceptions and returning error response
            return json.Response({"data":[]},f"{e}Internal Server Error", 400,False)