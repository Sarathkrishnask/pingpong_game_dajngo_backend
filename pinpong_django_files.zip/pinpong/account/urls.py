from django.urls import path
from account import views

app_name = 'account'

#Define the URL's
urlpatterns = [
    # Maps the URL pattern 'registeruser/' to the UserRegister view
    path('registeruser/',views.UserRegister.as_view(),name='registeruser'),

    # Maps the URL pattern 'AdminLoginApi/' to the AdminLoginApi view
    path('AdminLoginApi/',views.AdminLoginApi.as_view(),name='AdminLoginApi'),

    # Maps the URL pattern 'playerdata/' to the playerData view
    path('playerdata/',views.playerData.as_view(),name='playerdata'),

]