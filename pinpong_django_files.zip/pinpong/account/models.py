# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.contrib.auth import models as auth_models
from django.db import models
from django.utils.translation import gettext_lazy as _
from account import managers



class User(auth_models.AbstractBaseUser):
    """Custom user model that supports using email instead of username"""

    firstname = models.CharField(max_length=64)

    email = models.EmailField(max_length=64,blank=True,unique=True,null=True)

    phone_number = models.CharField(max_length=100, blank=True, null=True)
    
    objects = managers.UserManager()

    USERNAME_FIELD = 'email'

    """
    Below class method is used to create new user before it will check user already exist or not
    """

    @classmethod
    def create_user(cls, email):
        if email and not User.objects.filter(email=email).exists():
            User.objects.create_user(email=email)

"""
This is the player table where we save all the player data in database
"""

class PlayerHisory(models.Model):
    playername =  models.JSONField(null=True)
    whichgame =  models.CharField(max_length=50, blank=True, null = True)
    timeplayed =  models.CharField(max_length=50, blank=True, null = True)
    player_won =  models.CharField(max_length=50, blank=True, null = True)