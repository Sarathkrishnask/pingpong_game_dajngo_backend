"""
Email login validators
"""
from utils import functions
import json as j


from account.models import *


"""
Email and password keys validators
"""
def Email_Login_Validators(data):
    json_keys =['email','password']
    for val in json_keys:
        if  val not in dict.keys(data):
            return False
    return True


