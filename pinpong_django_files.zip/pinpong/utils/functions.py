
from rest_framework_simplejwt.tokens import AccessToken, RefreshToken
from account.models import *

"""
This below function is for generate the access and refresh tokens while login or register
"""

def emailauth(user,id):
    try:
        # Generate access and refresh tokens for the user
        access = AccessToken.for_user(user)
        refresh=RefreshToken.for_user(user)

        # Add email and user ID to tokens as additional information
        access['email']=user.email
        access['user_id']=id
        refresh['email']=user.email
        refresh['user_id']=id
        
        # Return access and refresh tokens as strings
        return {"access_token": str(access),
        "refresh_token":str(refresh)}
    except Exception as e:
        # Return False if an exception occurs
        return False
